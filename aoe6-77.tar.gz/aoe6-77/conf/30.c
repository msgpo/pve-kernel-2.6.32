#include <linux/hdreg.h>
#include <linux/ata.h>

int
testfn(int a, int b)
{
	return a + b;
}
