/* struct disk_attribute is defined in kernel headers */
