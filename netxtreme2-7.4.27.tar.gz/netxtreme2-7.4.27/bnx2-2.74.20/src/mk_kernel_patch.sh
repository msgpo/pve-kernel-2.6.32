#!/bin/sh
# Copyright (c) 2008-2012 Broadcom Corporation

if [ $# -lt 1 ]; then
	echo "$0: No kernel version provided." 1>&2
	KVER=$(uname -r)
	echo "$0: Using $KVER." 1>&2
else
	KVER=$1
fi

KSRC="/lib/modules/$KVER/source"

if [ -e "$KSRC/drivers/net/ethernet/broadcom" ]; then
	BSRC="$KSRC/drivers/net/ethernet/broadcom/"
	ALOCAL="a/drivers/net/ethernet/broadcom"
	BLOCAL="b/drivers/net/ethernet/broadcom"
elif [ -e "$KSRC/drivers/net" ]; then
	BSRC="$KSRC/drivers/net/"
	ALOCAL="a/drivers/net/"
	BLOCAL="b/drivers/net/"
else
	echo "$0: kernel tree not found." 1>&2
	exit 255
fi

mkdir -p $ALOCAL
mkdir -p $BLOCAL

cp $BSRC/bnx2.[ch] $ALOCAL
cp $BSRC/bnx2_fw*.h $ALOCAL
cp bnx2.[ch] $BLOCAL
cp bnx2_fw*.h $BLOCAL

if grep -q "skb_transport_offset" $KSRC/include/linux/skbuff.h ; then
  echo "#define NEW_SKB" > $BLOCAL/bnx2_compat.h
fi

if grep -q "static inline struct iphdr \*ip_hdr" $KSRC/include/linux/ip.h ; then
  echo "#define HAVE_IP_HDR" >> $BLOCAL/bnx2_compat.h
fi

if grep -q "__le32" $KSRC/include/linux/types.h ; then
  echo "#define HAVE_LE32" >> $BLOCAL/bnx2_compat.h
fi

if grep -q "gfp_t" $KSRC/include/linux/types.h ; then
  echo "#define HAVE_GFP" >> $BLOCAL/bnx2_compat.h
elif grep -q "gfp_t" $KSRC/include/linux/gfp.h ; then
  echo "#define HAVE_GFP" >> $BLOCAL/bnx2_compat.h
fi

if grep -q "bool" $KSRC/include/linux/types.h ; then
  echo "#define HAVE_BOOL" >> $BLOCAL/bnx2_compat.h
fi

if [ -e $KSRC/include/linux/aer.h ] ; then
  echo "#define HAVE_AER" >> $BLOCAL/bnx2_compat.h
fi

if grep -q "dev_err" $KSRC/include/linux/device.h ; then
  echo "#define HAVE_DEV_ERR" >> $BLOCAL/bnx2_compat.h
fi

if grep -q "dev_printk" $KSRC/include/linux/device.h ; then
  echo "#define HAVE_DEV_PRINTK" >> $BLOCAL/bnx2_compat.h
fi

if grep -q "netif_set_real_num_rx" $KSRC/include/linux/netdevice.h ; then
  echo "#define HAVE_REAL_RX" >> $BLOCAL/bnx2_compat.h
fi

if grep -q "netif_set_real_num_tx" $KSRC/include/linux/netdevice.h ; then
  echo "#define HAVE_REAL_TX" >> $BLOCAL/bnx2_compat.h
fi

if grep -q "skb_frag_size" $KSRC/include/linux/skbuff.h ; then
  echo "#define HAVE_SKB_FRAG" >> $BLOCAL/bnx2_compat.h
fi

if grep -q "ethtool_adv_to_mii_adv_t" $KSRC/include/linux/mii.h ; then
  echo "#define HAVE_ETHTOOL_TO_MII" >> $BLOCAL/bnx2_compat.h
fi

if grep -q "pci_is_pcie" $KSRC/include/linux/pci.h ; then
  echo "#define HAVE_IS_PCIE" >> $BLOCAL/bnx2_compat.h
fi

sed -e 's/#define BCM_CNIC 1//' \
    -e 's/#include "cnic_if.h"//' \
    -e '/#include <linux\/version.h>/ a\
#include "bnx2_compat.h"
' < bnx2.c > $BLOCAL/bnx2.c

diff -Nrup a b > bnx2-$KVER.patch

rm -rf a b
